/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// this file is not used, this code is written in core/js/js.js to execute
$(document).ready(function(){
    alert();
    $('.left-right').mouseover(function(){
        $('.slider').stop().animate({
            right: 0    
        }, 400);                        
    }).mouseout(function(){
        $('.slider').stop().animate({
            right: '-200px'    
        }, 400);     
    });
    
    $('.left').click(function(){
        $('.slider').stop().animate({
            right: 0    
        }, 250);                        
    });
    
    $('.right').click(function(){
            $('.slider').stop().animate({
                right: '-245px'    
            }, 250);     
        });

});